const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');

module.exports = router;
